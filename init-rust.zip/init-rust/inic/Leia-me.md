# programa cria o mascote da linguagem

> programa foi criado com algumas forma de desenvolvimeto
> para chegar nesse codigo bem resumido
> teve varios erros mais corrigir e cheguei no resultado satisfatório!!
> estou na qualidade de iniciante



