use ferris_says::say;
use std::io::stderr;
use std::io::BufWriter;

//dessa forma funciona, mais pode ficar um pouco confuso!
//mais vc pode desenvolver em forma mais legivel eu que fiz assim!

fn main() {
    let stderr = stderr();
    let message = String::from("Hello fellow Rustaceans! Novo");
    let fill = 150;

    let mut writer = BufWriter::new(stderr.lock());

    say(&message, fill, &mut writer).unwrap();
}
